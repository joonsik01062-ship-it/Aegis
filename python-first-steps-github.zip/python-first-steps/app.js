
const $=s=>document.querySelector(s);
const ta=$('#ta'),pre=$('#pre'),gut=$('#gut'),sug=$('#sug'),msg=$('#msg'),wrap=$('#wrap');
const KW=new Set('False None True and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield'.split(' '));
const BI=new Set('print input len range int str float list dict set tuple bool type sum min max abs round sorted enumerate zip map filter open isinstance reversed any all chr ord format id dir help pow divmod bin hex oct repr hash iter next object super Exception ValueError TypeError KeyError IndexError ZeroDivisionError NameError FileNotFoundError StopIteration __name__'.split(' '));
const POP=[['print','f'],['input','f'],['len','f'],['range','f'],['int','f'],['str','f'],['float','f'],['list','f'],['def','k'],['if','k'],['for','k'],['while','k'],['import','k'],['return','k'],['else','k'],['elif','k'],['in','k'],['True','k'],['False','k'],['None','k'],['class','k'],['try','k'],['except','k'],['break','k'],['continue','k'],['pass','k'],['sum','f'],['max','f'],['min','f'],['abs','f'],['round','f'],['sorted','f'],['enumerate','f'],['zip','f'],['open','f'],['type','f'],['dict','f'],['set','f'],['tuple','f'],['bool','f'],['and','k'],['or','k'],['not','k'],['with','k'],['as','k'],['from','k'],['lambda','k'],['isinstance','f'],['map','f'],['filter','f'],['finally','k'],['raise','k'],['is','k']];
const METH=['append','split','join','strip','format','upper','lower','replace','items','keys','values','sort','pop','remove','count','index','extend','insert','startswith','endswith','find'].map(x=>[x,'f']);
'pow reversed divmod eval exit hex oct bin chr ord id dir help hash iter next any all repr format callable vars'.split(' ').forEach(x=>POP.push([x,'f']));
'math random time datetime os sys json re self __init__ global nonlocal assert del yield async await pickle pprint property'.split(' ').forEach(x=>POP.push([x,'v']));
const SP=new Set('if elif while for in and or not is import from return with as lambda class def except'.split(' ')),CO=new Set(['else','try','finally']);
const BLOCK=/^(if|elif|else|for|while|def|class|with|try|except|finally)\b/;
const cnt=(s,set)=>[...s].filter(c=>set.includes(c)).length;
const ids=s=>(s.match(/[A-Za-z_]\w*/g)||[]).filter(x=>!KW.has(x));
function lev(a,b){const d=[];for(let i=0;i<=a.length;i++)d[i]=[i];for(let j=1;j<=b.length;j++)d[0][j]=j;for(let i=1;i<=a.length;i++)for(let j=1;j<=b.length;j++)d[i][j]=Math.min(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+(a[i-1]===b[j-1]?0:1));return d[a.length][b.length]}
function pre1(t){const o=[];let m;
 if(m=t.match(/^(?:async\s+)?def\s+(\w+)\s*\(([^)]*)/)){o.push(m[1]);m[2].split(',').forEach(p=>{const q=p.trim().replace(/^\*+/,'').match(/^[A-Za-z_]\w*/);if(q)o.push(q[0])})}
 if(m=t.match(/^class\s+(\w+)/))o.push(m[1]);
 if(m=t.match(/^import\s+(.+)/))m[1].split(',').forEach(p=>{const q=p.trim().split(/\s+as\s+/);const nm=(q[1]||q[0]).trim().split('.')[0];if(nm)o.push(nm)});
 if(m=t.match(/^from\s+[\w.]+\s+import\s+(.+)/))m[1].replace(/[()]/g,'').split(',').forEach(p=>{const q=p.trim().split(/\s+as\s+/);const nm=(q[1]||q[0]).trim();if(nm&&nm!=='*')o.push(nm)});
 for(const r of t.matchAll(/\bfor\s+([\w\s,()*]+?)\s+in\b/g))o.push(...ids(r[1]));
 for(const r of t.matchAll(/\bas\s+(\w+)/g))o.push(r[1]);
 for(const r of t.matchAll(/(\w+)\s*:=/g))o.push(r[1]);
 for(const r of t.matchAll(/\blambda\b([^:]*):/g))o.push(...ids(r[1].replace(/=[^,]*/g,'')));
 return o}
function post1(t){const o=[];let rest=t,m;while(m=rest.match(/^\s*([A-Za-z_*][\w\s,*]*?)\s*=(?!=)(.*)$/)){ids(m[1]).forEach(x=>o.push(x));rest=m[2]}return o}
function postLen(t){let rest=t,m,len=0;while(m=rest.match(/^\s*([A-Za-z_*][\w\s,*]*?)\s*=(?!=)(.*)$/)){len+=rest.length-m[2].length;rest=m[2]}return len}
let userNames=[];
function analyze(src){
 const L=src.split('\n'),n=L.length,res=new Array(n).fill(null);
 const mark=(i,lv,t)=>{if(!res[i]||(lv==='r'&&res[i].lv!=='r'))res[i]={lv,t}};
 const C=[],D0=[],stack=[];let tri=null;
 for(let i=0;i<n;i++){
  const s=L[i];let out='',j=0,bad=false;
  while(j<s.length){
   if(tri){const k=s.indexOf(tri,j);if(k<0){j=s.length;break}j=k+3;tri=null;out+='""';continue}
   const c=s[j];
   if(c==='#')break;
   if(c==='"'||c==="'"){
    out=out.replace(/(?<![\w])[rRbBfFuU]{1,2}$/,'');
    if(s.substr(j,3)===c+c+c){tri=c+c+c;j+=3;continue}
    let k=j+1;while(k<s.length&&s[k]!==c){if(s[k]==='\\')k++;k++}
    if(k>=s.length){bad=true;out+='""';break}
    out+='""';j=k+1;continue}
   out+=c;j++}
  C.push(out);D0.push(stack.length);
  if(bad)mark(i,'r','따옴표가 안 닫혔어요. 글자 끝에 같은 따옴표를 하나 더 붙여 주세요.');
  for(const ch of out){
   if('([{'.includes(ch))stack.push({ch,i});
   else if(')]}'.includes(ch)){const o=stack.pop();if(!o||'([{'.indexOf(o.ch)!==')]}'.indexOf(ch))mark(i,'r','닫는 괄호 '+ch+' 가 짝이 안 맞아요. 여는 괄호와 닫는 괄호 개수를 확인해 보세요.')}}
 }
 stack.forEach(o=>mark(o.i,'r','여는 괄호 '+o.ch+' 가 안 닫혔어요. 닫는 괄호를 붙여 주세요.'));
 let pI=-1,pStart='',pLast='';
 for(let i=0;i<n;i++){
  const t=C[i].trim();if(!t)continue;
  if(D0[i]>0){pLast=t;continue}
  const I=L[i].match(/^ */)[0].length;
  if(pI>=0){const opens=BLOCK.test(pStart)&&/:\s*$/.test(pLast);
   if(opens&&I<=pI)mark(i,'r','위 줄이 : 로 끝나서 이 줄은 안쪽으로 들여쓰기(스페이스 4칸)가 필요해요.');
   else if(!opens&&I>pI)mark(i,'r','들여쓰기가 갑자기 늘었어요. 위 줄과 줄을 맞춰 주세요.')}
  if(BLOCK.test(t)&&cnt(t,'([{')===cnt(t,')]}')&&!t.includes(':'))mark(i,'r','줄 끝에 : 가 빠졌어요. 예) if a > 3:');
  if(/^(if|elif|while)\b/.test(t)){let f=t;for(let q=0;q<5;q++)f=f.replace(/\([^()]*\)/g,'');if(/(?<![=!<>:])=(?!=)/.test(f))mark(i,'r','조건에는 = 말고 == 를 써야 해요. (같은지 비교할 때는 ==)')}
  pI=I;pStart=t;pLast=t;
 }
 const P=[],Q=[],all=new Set(BI);
 for(let i=0;i<n;i++){const t=C[i].trim();const a=t?pre1(t):[],b=t?post1(t):[];P.push(a);Q.push(b);a.concat(b).forEach(x=>all.add(x))}
 const defd=new Set(BI);
 for(let i=0;i<n;i++){
  const t=C[i].trim();P[i].forEach(x=>defd.add(x));
  if(t&&!(res[i]&&res[i].lv==='r')&&!/^(import|from|global|nonlocal)\b/.test(t)){
   let tt=t.replace(/^(?:async\s+)?def\s+\w+/,'').replace(/^class\s+\w+/,'');tt=tt.slice(postLen(tt));
   const ind=L[i].match(/^ */)[0].length;
   for(const r of tt.matchAll(/(?<![\w.])[A-Za-z_]\w*/g)){
    const w=r[0];if(KW.has(w)||defd.has(w))continue;
    const bf=tt.slice(0,r.index),depth=D0[i]+cnt(bf,'([{')-cnt(bf,')]}');
    if(depth>0&&/^\s*=(?!=)/.test(tt.slice(r.index+w.length)))continue;
    if(all.has(w)&&ind>0)continue;
    let best=null,bd=3;defd.forEach(c=>{if(c.length>2&&!c.startsWith('__')){const d=lev(w.toLowerCase(),c.toLowerCase());if(d<bd){bd=d;best=c}}});
    mark(i,'y',w+' 를 아직 못 찾았어요. 먼저 만들었는지 확인해 보세요.'+(best&&w.length>2?' 혹시 '+best+' 아닌가요?':''));
    break}
  }
  Q[i].forEach(x=>defd.add(x));
 }
 userNames=[...all].filter(x=>!BI.has(x));
 return res}
let res=[];
function render(){
 const L=ta.value.split('\n');res=analyze(ta.value);
 pre.innerHTML=L.map((_,i)=>'<div class="'+(res[i]?res[i].lv:'')+'"></div>').join('');
 gut.innerHTML=L.map((_,i)=>'<div class="n '+(res[i]?res[i].lv:'')+'">'+(i+1)+'</div>').join('');
 const mx=Math.max(...L.map(l=>l.length));
 ta.style.height='0px';const lh=Math.max(10,(ta.scrollHeight-132)/L.length);window.LH=lh;document.documentElement.style.setProperty('--lh',lh+'px');ta.style.height=(L.length*lh+132)+'px';ta.style.width='calc('+(mx+4)+'ch + 24px)';
}
let flashT=0;
function flash(t){msg.className='';msg.textContent=t;flashT=Date.now()+3000}
function status(){
 if(Date.now()<flashT)return;
 const li=ta.value.slice(0,ta.selectionStart).split('\n').length-1,r=res[li];
 if(r){msg.className=r.lv;msg.textContent=(li+1)+'번째 줄: '+r.t;return}
 const nr=res.filter(x=>x&&x.lv==='r').length,ny=res.filter(x=>x&&x.lv==='y').length;
 if(!nr&&!ny){msg.className='ok';msg.textContent='좋아요! 지금은 문제가 없어요.'}
 else{msg.className='';msg.textContent='빨간 줄 '+nr+'개, 노란 줄 '+ny+'개. 줄을 누르면 설명이 나와요.'}
}
function suggest(){
 const p=ta.selectionStart,b=ta.value.slice(0,p),m=b.match(/([A-Za-z_]\w*)$/);
 if(m&&ta.selectionEnd===p){
  const w=m[1],lw=w.toLowerCase(),dot=b.slice(0,p-w.length).endsWith('.');
  let pool=dot?METH:POP.concat(userNames.map(x=>[x,'v']));
  const seen=new Set(),list=[];
  const add=f=>{for(const x of pool){if(list.length>=5)return;if(x[0]!==w&&!seen.has(x[0])&&f(x[0].toLowerCase())){seen.add(x[0]);list.push(x)}}};
  add(c=>c.startsWith(lw));
  if(w.length>1)add(c=>lev(lw,c)<=(lw.length>4?2:1));
  add(c=>c.includes(lw));
  add(()=>true);
  const key=list.map(x=>x[0]).join('|');if(sug.dataset.k===key&&sug.querySelector('.chip'))return;sug.dataset.k=key;sug.innerHTML='';
  list.forEach(x=>{const c=document.createElement('button');c.type='button';c.className='chip';c.textContent=x[0];c.onpointerdown=e=>e.preventDefault();c.onclick=()=>pick(x[0],x[1]);sug.appendChild(c)});
  if(list.length)return}
 sug.dataset.k='';sug.textContent='글자를 치면 여기에 추천이 나와요';
}
function pick(w,t){
 const p=ta.selectionStart,m=ta.value.slice(0,p).match(/[A-Za-z_]\w*$/);if(!m)return;
 const s=p-m[1].length;let ins=w,back=0;
 if(t==='f'&&ta.value[p]!=='('){ins=w+'()';back=1}else if(SP.has(w))ins=w+' ';else if(CO.has(w))ins=w+':';
 ta.focus();ta.setSelectionRange(s,p);let okk=false;try{okk=document.execCommand('insertText',false,ins)}catch(e){}if(!okk)ta.setRangeText(ins,s,p,'end');const q=s+ins.length-back;ta.setSelectionRange(q,q);update();
}
function keepCaret(){
 const li=ta.value.slice(0,ta.selectionStart).split('\n').length-1,top=li*(window.LH||24)+12;
 if(top<wrap.scrollTop)wrap.scrollTop=top;
 else if(top+48>wrap.scrollTop+wrap.clientHeight)wrap.scrollTop=top+48-wrap.clientHeight;
}
function update(){render();ta.scrollTop=0;ta.scrollLeft=0;suggest();status();keepCaret()}
ta.addEventListener('input',update);
const PAIR={'(':')','[':']','{':'}','"':'"',"'":"'"};
ta.addEventListener('input',e=>{
 if(e.isComposing||e.inputType!=='insertText'||!e.data||e.data.length!==1)return;
 const d=e.data,p=ta.selectionStart,v=ta.value;
 if(')]}"\''.includes(d)&&v[p]===d&&v[p-1]===d){ta.setRangeText('',p-1,p,'end');ta.setSelectionRange(p,p);update();return}
 if(!PAIR[d])return;
 const isQ=d==='"'||d==="'";
 if(/\w/.test(v[p]||''))return;
 if(isQ&&/\w/.test(v[p-2]||'')&&!/(^|[^\w])[rbfuRBFU]$/.test(v.slice(0,p-1)))return;
 ta.setRangeText(PAIR[d],p,p,'start');update();
});
ta.addEventListener('beforeinput',e=>{
 if(e.inputType!=='deleteContentBackward'||ta.selectionStart!==ta.selectionEnd)return;
 const p=ta.selectionStart,v=ta.value;
 if(p>0&&PAIR[v[p-1]]&&PAIR[v[p-1]]===v[p]){e.preventDefault();ta.setRangeText('',p-1,p+1,'end');update()}
});
document.addEventListener('selectionchange',()=>{if(document.activeElement===ta){suggest();status()}});
ta.addEventListener('keydown',e=>{
 if(e.key==='Tab'){e.preventDefault();ta.setRangeText('    ',ta.selectionStart,ta.selectionEnd,'end');update()}
 else if(e.key==='Enter'){e.preventDefault();
  const p=ta.selectionStart,line=ta.value.slice(0,p).split('\n').pop();
  let sp=line.match(/^ */)[0];if(/:\s*$/.test(line.replace(/#.*$/,'')))sp+='    ';
  ta.setRangeText('\n'+sp,p,ta.selectionEnd,'end');update()}
});
const out=$('#out'),panel=$('#panel'),ir=$('#ir'),iin=$('#iin');let psz='full',running=false;
function write(t,c){const s=document.createElement('span');if(c)s.className=c;s.textContent=t;out.appendChild(s);out.scrollTop=out.scrollHeight}
function showPanel(){panel.className='open '+psz}
$('#pclose').onclick=()=>{panel.className='';ir.classList.remove('open')};
$('#psize').onchange=e=>{psz=e.target.value;showPanel()};
function askInput(p){return new Promise(res=>{write(p||'');ir.classList.add('open');iin.value='';iin.focus();const go=()=>{const v=iin.value;ir.classList.remove('open');write(v+'\n','ok');iin.onkeydown=null;$('#isend').onclick=null;res(v)};iin.onkeydown=e=>{if(e.key==='Enter')go()};$('#isend').onclick=go})}
function koErr(s,line){
 const t=s.split(':')[0].trim(),L=ta.value.split('\n'),src=L[line-1]||'';let what,fix;
 if(t==='NameError'){const m=s.match(/name '(.+?)'/),nm=m?m[1]:'';let best=null,bd=3;[...BI,...userNames].forEach(c=>{const d=lev(nm.toLowerCase(),c.toLowerCase());if(c.length>2&&d<bd){bd=d;best=c}});what=nm+' 라는 이름을 못 찾았어요.';fix=best?'혹시 '+best+' 를 쓰려던 게 아닌가요? 오타가 아니라면 '+nm+' 을 먼저 만들어야 해요.':nm+' 을 먼저 만들어야 해요. 예) '+nm+' = 0'}
 else if(t==='TypeError'){what='종류가 다른 값끼리 계산하거나 합치려고 했어요.';fix=/input\s*\(/.test(src)||/input/.test(ta.value)?'input() 으로 받은 값은 글자예요. 숫자로 계산하려면 int(input(...)) 처럼 감싸 주세요.':'글자와 숫자를 + 로 합치지 말고, str(숫자) 로 바꾸거나 쉼표(,)로 나눠 써 보세요.'}
 else if(t==='ValueError'){what='값의 모양이 맞지 않아요. (예: 숫자가 아닌 글자를 int() 로 바꾸려는 경우)';fix='숫자만 입력했는지 확인해 보세요.'}
 else if(t==='ZeroDivisionError'){what='0으로 나눌 수는 없어요.';fix='나누는 수가 0이 아닌지 확인해 보세요.'}
 else if(t==='IndexError'){what='리스트에 없는 번호의 칸을 꺼내려고 했어요.';fix='번호는 0부터 시작해요. len(리스트) 로 개수를 확인해 보세요.'}
 else if(t==='KeyError'){what='딕셔너리에 없는 키를 꺼내려고 했어요.';fix='키 이름의 오타를 확인해 보세요.'}
 else if(t==='AttributeError'){what='그 값에는 없는 기능을 쓰려고 했어요.';fix='점(.) 뒤의 이름이 맞는지, 값의 종류가 맞는지 확인해 보세요.'}
 else if(/Indentation/.test(t)){what='들여쓰기가 맞지 않아요.';fix=': 로 끝난 줄 아래는 스페이스 4칸 안쪽으로 맞춰 주세요.'}
 else if(/Syntax|Parse/.test(t)){what='문법이 틀렸어요.';fix='괄호와 따옴표가 닫혔는지, if/for/def 줄 끝에 : 가 있는지 확인해 보세요.'}
 else if(/Import|ModuleNotFound/.test(t)){what='불러오려는 모듈을 이 실행기에서 못 찾았어요.';fix='모듈 이름의 오타를 확인해 보세요. 이 실행기에는 없는 모듈일 수도 있어요.'}
 else{what='예상하지 못한 오류가 났어요.';fix='아래 원래 오류 문장과 근처 코드를 확인해 보세요. 이 오류는 저도 정확한 해결법을 잘 몰라요.'}
 return{what,fix}}
function showErr(e){
 const s=String(e&&e.toString?e.toString():e);let ln=0;
 try{if(e.traceback&&e.traceback[0])ln=e.traceback[0].lineno}catch(x){}
 if(!ln){const m=s.match(/line (\d+)/);if(m)ln=+m[1]}
 const k=koErr(s,ln),L=ta.value.split('\n');
 write('\n오류가 났어요\n','e');write(k.what+'\n');
 if(ln){write(ln+'번째 줄 근처예요.\n');const a=Math.max(0,ln-2),b=Math.min(L.length-1,ln);for(let i=a;i<=b;i++)write((i+1)+(i+1===ln?' ▶ ':'    ')+L[i]+'\n',i+1===ln?'e':'ok')}
 write('\n고치는 방법: '+k.fix+'\n');write('\n원래 오류: '+s+'\n','ok')}
const SKSRC=[['https://cdnjs.cloudflare.com/ajax/libs/skulpt/1.2.0/skulpt.min.js','https://cdnjs.cloudflare.com/ajax/libs/skulpt/1.2.0/skulpt-stdlib.js'],['https://cdn.jsdelivr.net/npm/skulpt@1.2.0/dist/skulpt.min.js','https://cdn.jsdelivr.net/npm/skulpt@1.2.0/dist/skulpt-stdlib.js'],['https://cdn.jsdelivr.net/npm/skulpt@1.2.0/skulpt.min.js','https://cdn.jsdelivr.net/npm/skulpt@1.2.0/skulpt-stdlib.js'],['https://skulpt.org/js/skulpt.min.js','https://skulpt.org/js/skulpt-stdlib.js']];
function ldJs(u){return new Promise((ok,no)=>{const e=document.createElement('script');e.src=u;e.onload=ok;e.onerror=no;document.head.appendChild(e)})}
let skP=null;
function loadSk(){
 if(window.Sk&&Sk.builtinFiles)return Promise.resolve(true);
 if(skP)return skP;
 skP=(async()=>{for(const [a,b] of SKSRC){try{await ldJs(a);await ldJs(b);if(window.Sk&&Sk.builtinFiles)return true}catch(e){}}skP=null;return false})();
 return skP}
let runId=0;
async function runCode(){
 const my=++runId;
 out.textContent='';ir.classList.remove('open');showPanel();
 write('파이썬 실행기를 준비하는 중...\n','ok');
 const ok=await loadSk();
 if(my!==runId)return;
 out.textContent='';
 if(!ok){write('파이썬 실행기를 불러오지 못했어요.\n인터넷 연결을 확인하고 새로고침해 보세요. 그래도 안 되면 이 기기나 네트워크에서 실행기 주소가 막혀 있을 수 있어요.\n','e');return}
 Sk.configure({output:t=>{if(my===runId)write(t)},read:f=>{if(Sk.builtinFiles===undefined||Sk.builtinFiles.files[f]===undefined)throw new Error('File not found: '+f);return Sk.builtinFiles.files[f]},inputfun:askInput,inputfunTakesPrompt:true,__future__:Sk.python3});
 try{await Sk.misceval.asyncToPromise(()=>Sk.importMainWithBody('<stdin>',false,ta.value,true));if(my===runId)write('\n실행이 끝났어요.\n','ok')}
 catch(e){if(my===runId)showErr(e)}
}
$('#run').onclick=runCode;
loadSk();
const VP=$('#vp'),vin=$('#vin'),vh=$('#vh');
const NOUN={이름:'name',나이:'age',숫자:'num',수:'num',점수:'score',값:'value',문자:'text',글자:'text',단어:'word',문장:'sentence',키:'height',몸무게:'weight',온도:'temp',가격:'price'};
const NUMV=new Set(['age','num','score','value','height','weight','temp','price']);
const DEF={a:10,b:5,c:3,d:2,x:10,y:5,n:5,num:7,age:20,score:80,value:1,height:170,weight:65,temp:25,price:1000};
const PT='(?:을|를|은|는|이|가|와|과|랑|로|으로|에|의)';
const ISV=t=>/^-?\d+(\.\d+)?$/.test(t)||/^[A-Za-z_]\w*$/.test(t);
function newVar(ctx){for(const c of 'abcdefghijklmnopqrstuvwxyz'){if(!ctx.vars.has(c)){ctx.vars.add(c);return c}}return 'v'+ctx.vars.size}
function ensure(n,ctx){if(ctx.vars.has(n))return;ctx.vars.add(n);const d=DEF[n];ctx.pre.push(n+' = '+(d===undefined?(['name','text','word','sentence'].includes(n)?'"철수"':'0'):d))}
function clean(t){t=t.trim();const m=t.match(new RegExp('^([A-Za-z_]\\w*|-?\\d+(?:\\.\\d+)?)'+PT+'?$'));if(m)return m[1];for(const k in NOUN){if(t===k)return k;if(new RegExp('^'+k+PT+'$').test(t))return k}return t}
function val(s,ctx){s=(s||'').trim();if(!s)return null;
 const q=s.match(/^["'“”‘’](.*)["'“”‘’]$/);if(q)return JSON.stringify(q[1]);
 s=clean(s);
 if(/^-?\d+(\.\d+)?$/.test(s))return s;
 if(/^(결과|그값|답|합계)$/.test(s.replace(/\s/g,''))&&ctx.res)return ctx.res;
 if(NOUN[s]){ensure(NOUN[s],ctx);return NOUN[s]}
 if(ctx.vars.has(s))return s;
 if(/^[A-Za-z_]\w*$/.test(s)&&s.length<=2){ensure(s,ctx);return s}
 return JSON.stringify(s)}
const ind=a=>a.map(x=>'    '+x);
function tgt(c,ctx){const m=c.match(/(\S+?)(?:에|로|으로)\s*(?:저장|넣)/);if(!m)return null;let t=clean(m[1]);if(!/^[A-Za-z_]\w*$/.test(t))t=NOUN[t]||newVar(ctx);return t}
function cnd(s,ctx){s=s.trim();let m;
 if(m=s.match(/(\S+?)(?:이|가|은|는)?\s*짝수/))return val(m[1],ctx)+' % 2 == 0';
 if(m=s.match(/(\S+?)(?:이|가|은|는)?\s*홀수/))return val(m[1],ctx)+' % 2 == 1';
 if(m=s.match(/(\S+?)(?:이|가|은|는)?\s*양수/))return val(m[1],ctx)+' > 0';
 if(m=s.match(/(\S+?)(?:이|가|은|는)?\s*음수/))return val(m[1],ctx)+' < 0';
 m=s.match(/^(\S+?)(?:이|가|은|는)?\s+(\S+?)(?:와|과|랑|보다)?\s*(크|작|같|다르|많|적|높|낮|이상|이하|초과|미만)/);
 if(!m)return null;
 const op={크:'>',많:'>',높:'>',초과:'>',작:'<',적:'<',낮:'<',미만:'<',이상:'>=',이하:'<=',같:'==',다르:'!='}[m[3]];
 return val(m[1],ctx)+' '+op+' '+val(m[2],ctx)}
function ifc(c,ctx){
 const m=c.match(/^(.*?)(?:이?면|라면)\s*,?\s*(.*)$/);if(!m||!m[2])return null;
 const cond=cnd(m[1],ctx);if(!cond)return null;
 const sp=m[2].split(/\s*,?\s*(?:아니면|그렇지\s*않으면|아니라면)\s*,?\s*/);
 const A=clause(sp[0].replace(/[,\s]+$/,''),ctx);if(!A)return null;
 const B=sp[1]?clause(sp[1].replace(/[,\s]+$/,''),ctx):null;
 const L=['if '+cond+':',...ind(A)];if(B)L.push('else:',...ind(B));return L}
function inp(c,ctx){
 if(!/입력\s*(?:을\s*)?(?:받|해)/.test(c))return null;
 const mm=c.match(/입력\s*(?:을\s*)?(?:받아서|받아|받고|받|해서|해)/);
 const rest=mm?c.slice(mm.index+mm[0].length).replace(/^[\s,]+/,''):'';
 const L=[];let v;
 if(/(두|2)\s*(개의\s*)?(수|숫자|정수)/.test(c)){const a=newVar(ctx),b=newVar(ctx);L.push(a+' = int(input("첫 번째 숫자: "))',b+' = int(input("두 번째 숫자: "))');ctx.last=b;ctx.res=null;return L}
 let noun=null;for(const k in NOUN){if(c.includes(k)){noun=k;break}}
 v=tgt(c,ctx);if(!v)v=noun?NOUN[noun]:newVar(ctx);
 const num=/정수|숫자|나이|점수|몸무게|키|온도|가격/.test(c)||NUMV.has(v);
 let e='input("'+(noun||'값')+' 입력: ")';
 if(/실수/.test(c))e='float('+e+')';else if(num)e='int('+e+')';
 ctx.vars.add(v);ctx.last=v;L.push(v+' = '+e);
 if(rest&&!/저장|넣/.test(rest)){
  if(/^(그\s*값|입력\s*받은\s*값)?\s*(?:을|를)?\s*(출력|프린트|보여|표시)/.test(rest))L.push('print('+v+')');
  else{const p=rest.match(/^(.+?)\s*(?:을|를)?\s*(출력|프린트|보여|표시|찍어)/);
   if(p)L.push('print('+val(p[1],ctx)+', '+v+')');else{const r=clause(rest,ctx);if(r)L.push(...r)}}}
 return L}
function asg(c,ctx){
 const m=c.match(/^(\S+?)(?:에|은|는|를|을)?\s+(.+?)\s*(?:을|를|으로|로)?\s*(?:저장|넣어|넣|대입|설정|라고\s*해|로\s*해)/);
 if(!m)return null;let v=clean(m[1]);
 if(!/^[A-Za-z_]\w*$/.test(v))v=NOUN[v]||newVar(ctx);
 const x=val(m[2],ctx);if(x===null)return null;
 ctx.vars.add(v);ctx.res=v;return [v+' = '+x]}
function lname(ctx){if(ctx.list)return ctx.list;const n=[...ctx.vars].find(v=>/^(nums|items|list|numbers|arr)$/.test(v));if(n){ctx.list=n;return n}ctx.vars.add('nums');ctx.pre.push('nums = [3, 1, 2]');ctx.list='nums';return 'nums'}
function lst(c,ctx){
 const ex=/(리스트|목록)/.test(c);
 if(!ex&&!(ctx.list&&/정렬|추가|뒤집|최대|최소|평균/.test(c)))return null;
 if(ex&&/만들|생성|선언/.test(c)&&!/추가/.test(c)){
  const nums=c.match(/-?\d+(?:\.\d+)?/g)||[];
  if(nums.length){ctx.vars.add('nums');ctx.list='nums';return ['nums = ['+nums.join(', ')+']']}
  const ws=c.split(/[\s,]+/).filter(w=>w&&!/(리스트|목록|만들|생성|선언|담|넣)/.test(w));
  if(ws.length){ctx.vars.add('items');ctx.list='items';return ['items = ['+ws.map(w=>JSON.stringify(w)).join(', ')+']']}
  ctx.vars.add('nums');ctx.list='nums';return ['nums = [1, 2, 3]']}
 const n=lname(ctx),pr=/출력|보여|찍/.test(c);
 if(/추가/.test(c)){const t=c.replace(/추가.*$/,'').replace(/(리스트|목록)(에서|에)?/,'').trim();return [n+'.append('+(val(t,ctx)||'0')+')']}
 if(/정렬/.test(c)){const L=[n+'.sort()'];if(pr)L.push('print('+n+')');return L}
 if(/뒤집|거꾸로|역순/.test(c)){const L=[n+'.reverse()'];if(pr)L.push('print('+n+')');return L}
 if(/길이|개수|몇\s*개/.test(c))return ['print(len('+n+'))'];
 if(/최대|최댓값|가장\s*큰/.test(c))return ['print(max('+n+'))'];
 if(/최소|최솟값|가장\s*작/.test(c))return ['print(min('+n+'))'];
 if(/평균/.test(c))return ['print(sum('+n+') / len('+n+'))'];
 if(/합/.test(c))return ['print(sum('+n+'))'];
 if(pr&&/하나씩|반복|전부|모두|순서대로/.test(c))return ['for item in '+n+':','    print(item)'];
 if(pr&&ex)return ['print('+n+')'];
 return null}
function rep(c,ctx){
 let m=c.match(/(\d+)\s*부터\s*(\d+)\s*까지/);
 if(m){const a=+m[1],b=+m[2],rest=c.slice(m.index+m[0].length);
  if(/합|더/.test(rest))return ['total = 0','for i in range('+a+', '+(b+1)+'):','    total += i','print(total)'];
  const f=/짝수/.test(rest)?'    if i % 2 == 0:':/홀수/.test(rest)?'    if i % 2 == 1:':null;
  const L=['for i in range('+a+', '+(b+1)+'):'];if(f)L.push(f,'        print(i)');else L.push('    print(i)');return L}
 m=c.match(/(\d+)\s*번/);
 if(m&&/반복|씩|해|출력|찍/.test(c)){
  const rest=c.slice(m.index+m[0].length).replace(/^\s*(?:반복해서|반복하면서|반복하며|반복|씩|동안)?[\s,]*/,'').trim();
  let b=rest?clause(rest,ctx):null;const pf=c.slice(0,m.index).trim();if(!b&&pf)b=clause(pf+' 출력',ctx);if(!b)b=['print(i)'];
  return ['for i in range('+m[1]+'):',...ind(b)]}
 if(/무한|계속\s*반복/.test(c)){
  const rest=c.replace(/.*?(?:무한\s*반복|계속\s*반복)(?:해서|하며|하면서)?[\s,]*/,'').trim();
  let b=rest?clause(rest,ctx):null;if(!b)b=['pass'];
  return ['while True:',...ind(b),'    # 멈추려면 break 를 쓰세요']}
 return null}
function rnd(c,ctx){
 if(!/랜덤|무작위|난수|주사위|로또/.test(c))return null;
 if(!ctx.imp&&!/import random/.test(ta.value)){ctx.imp=1;ctx.pre.unshift('import random')}
 if(/로또/.test(c))return ['lotto = sorted(random.sample(range(1, 46), 6))','print(lotto)'];
 if(/선택|뽑|중에/.test(c)&&ctx.list)return ['print(random.choice('+ctx.list+'))'];
 const m=c.match(/(\d+)\s*부터\s*(\d+)/),lo=m?m[1]:1,hi=m?m[2]:(/주사위/.test(c)?6:10);
 const t=tgt(c,ctx)||'r',pr=/출력|보여|알려|표시/.test(c)||!tgt(c,ctx);
 ctx.vars.add(t);ctx.res=t;
 const L=[t+' = random.randint('+lo+', '+hi+')'];if(pr)L.push('print('+t+')');return L}
const OPS=[[/나머지/,'%'],[/몫/,'//'],[/제곱/,'**'],[/더하|더해|더한/,'+'],[/빼기|빼|뺀/,'-'],[/곱하|곱해|곱한/,'*'],[/나누|나눠|나눈/,'/']];
const STOP=/^(출력|프린트|보여|표시|찍어|저장|계산|구해|알려|해|줘|결과)/;
function ari(c,ctx){
 let op=null,mi=-1,ml=0;
 for(const [r,o] of OPS){const m=c.match(r);if(m){op=o;mi=m.index;ml=m[0].length;break}}
 if(!op){const m=c.match(/(합|차|곱)(?:을|를)?\s*(?=출력|구해|보여|알려|계산)/);if(!m)return null;op={합:'+',차:'-',곱:'*'}[m[1]];mi=m.index;ml=m[1].length}
 const P=c.slice(0,mi),Q=c.slice(mi+ml).replace(/^(?:기|해서|해|한|하기)?[\s,]*/,'');
 const okv=t=>ISV(t)||NOUN[t]||ctx.vars.has(t);
 let toks=P.split(/\s*(?:와|과|랑|하고|,)\s*|\s+/).map(t=>t.replace(/(의|를|을|은|는)$/,'')).filter(t=>t&&!/^(두|세|수|숫자|정수|나눈|나눠|나누|더한|더해|뺀|곱한|곱해)$/.test(t)).map(clean).filter(okv);
 if(toks.length<2&&op!=='**'){const cq=clean(Q.split(/\s+/)[0].replace(/(의|를|을|은|는)$/,''));if(cq&&!STOP.test(cq)&&okv(cq))toks.push(cq)}
 let e;
 if(op==='**'){e=(toks[0]?val(toks[0],ctx):val('a',ctx))+' ** 2'}
 else{if(!toks.length)toks=['a','b'];else if(toks.length===1)toks.push(toks[0]==='b'?'a':'b');e=val(toks[0],ctx)+' '+op+' '+val(toks[1],ctx)}
 const t=tgt(c,ctx),pr=/출력|프린트|보여|표시|찍어|알려/.test(c);
 if(t){ctx.vars.add(t);ctx.res=t;const L=[t+' = '+e];if(pr)L.push('print('+t+')');return L}
 return pr?['print('+e+')']:['result = '+e,'print(result)']}
function fn(c,ctx){
 if(!/함수/.test(c))return null;
 const T=[[/더하|덧셈|합/,'add','a, b','a + b','add(3, 5)'],[/빼|뺄셈/,'sub','a, b','a - b','sub(5, 3)'],[/곱하|곱셈/,'mul','a, b','a * b','mul(3, 5)'],[/나누|나눗셈/,'div','a, b','a / b','div(10, 2)'],[/제곱/,'square','n','n ** 2','square(4)']];
 for(const t of T)if(t[0].test(c))return ['def '+t[1]+'('+t[2]+'):','    return '+t[3],'','print('+t[4]+')'];
 if(/인사/.test(c))return ['def greet(name):','    print("안녕하세요,", name)','','greet("철수")'];
 if(/짝수/.test(c))return ['def is_even(n):','    return n % 2 == 0','','print(is_even(4))'];
 const m=c.match(/([A-Za-z_]\w*)\s*(?:라는|이라는|이름의)?\s*함수/);
 return ['def '+(m?m[1]:'my_func')+'():','    # 여기에 할 일을 적으세요','    pass']}
function prt(c,ctx){
 const m=c.match(/^(.*?)\s*(?:을|를|은|는)?\s*(출력|프린트|보여|표시|찍어|말해|알려)/);
 if(!m||!m[1].trim())return null;
 if(m[2]==='알려'&&!(ISV(clean(m[1]))||ctx.vars.has(clean(m[1]))||NOUN[clean(m[1])]||/^(결과|합|합계|답)/.test(m[1].trim())))return null;
 const e=m[1].trim(),parts=e.split(/\s*(?:와|과|,|랑)\s*/);
 if(parts.length>1&&parts.every(p=>{const q=clean(p);return ISV(q)||ctx.vars.has(q)||NOUN[q]}))return ['print('+parts.map(p=>val(p,ctx)).join(', ')+')'];
 return ['print('+val(e,ctx)+')']}
const SYN=[[/사용법|쓰는\s*법|하는\s*법|사용|방법|예제|예시|연습|기본/g,''],[/프린트|찍어|찍기|보여줘|보여|표시해?|나타내|말해|뿌려/g,'출력'],[/만들어줘|만들어|만드는|만들기|생성해?|선언해?|작성해?|짜줘|짜/g,'만들'],[/입력받아서?|입력받고|입력받|입력해서?|입력하|물어봐|물어보|받아서/g,'입력'],[/더해서?|더하기|덧셈/g,'더하'],[/빼기|뺄셈/g,'빼'],[/곱하기|곱셈|곱해/g,'곱하'],[/나누기|나눗셈|나눠/g,'나누'],[/반복해서|반복문|루프/g,'반복'],[/리스트|목록|배열/g,'리스트'],[/딕셔너리|사전|dict/g,'딕셔너리'],[/함수를|함수가/g,'함수'],[/클래스를|클래스가/g,'클래스'],[/문자열|글자|스트링/g,'문자열'],[/조건문|만약/g,'조건'],[/해줘|해주세요|해줄래|줄래|줘|주세요|하고싶어|싶어|알려줘|알려/g,'']];
function norm(s){s=s.toLowerCase();for(const [r,t] of SYN)s=s.replace(r,t);return s.replace(/\d+(\.\d+)?/g,'#').replace(/[\s.,!?~"'“”‘’()\[\]]|[은는이가을를에의도]/g,'')}
function bg(s){const a=new Set();if(s.length===1)a.add(s);for(let i=0;i<s.length-1;i++)a.add(s.slice(i,i+2));return a}
const DICT=ENT.map(e=>{const raw=e[0].split('|');return{raw,b:raw.map(x=>bg(norm(x))),code:e[1]}});
function fill(code,t){
 const nums=t.match(/-?\d+(?:\.\d+)?/g)||[];
 const strs=[...t.matchAll(/["“”‘’']([^"“”‘’']+)["“”‘’']/g)].map(m=>m[1]);
 return code.replace(/\{([NS])(\d)(?::([^}]*))?\}/g,(_,k,i,d)=>{i=+i-1;if(k==='N')return nums[i]!==undefined?nums[i]:(d||'0');const s=strs[i];return JSON.stringify(s!==undefined?s:(d||'안녕하세요'))})}
function dictBest(c){
 const tb=bg(norm(c.replace(/["“”‘’'][^"“”‘’']*["“”‘’']/g,'')));
 if(!tb.size)return null;
 let best=null,bs=0;const all=[];
 for(const e of DICT){let es=0;for(const x of e.b){let n=0;x.forEach(g=>{if(tb.has(g))n++});const sc=.6*(n/x.size)+.4*(2*n/(tb.size+x.size));if(sc>es)es=sc}all.push([es,e]);if(es>bs){bs=es;best=e}}
 all.sort((a,b)=>b[0]-a[0]);
 return{e:best,s:bs,top:all.slice(0,3)}}
function clause(c,ctx){
 c=c.trim().replace(/[?!~]+$/,'').trim();if(!c)return null;
 const d=dictBest(c);
 if(d&&d.s>=0.72)return fill(d.e.code,c).split('\n');
 const pl=ctx.pre.length,vs=new Set(ctx.vars),ls=ctx.list,lr=ctx.res;
 const r=ifc(c,ctx)||inp(c,ctx)||lst(c,ctx)||rnd(c,ctx)||rep(c,ctx)||fn(c,ctx)||ari(c,ctx)||asg(c,ctx)||prt(c,ctx);
 if(r)return r;
 ctx.pre.length=pl;ctx.vars=vs;ctx.list=ls;ctx.res=lr;
 if(d&&d.s>=0.45)return fill(d.e.code,c).split('\n');
 ctx.sug=d?d.top.filter(x=>x[0]>=0.2).map(x=>x[1].raw[0]):[];
 return null}

const TP=[
[/구구단/,t=>{const n=t.match(/(\d+)단/);return (n?'dan = '+n[1]:'dan = int(input("몇 단을 볼까요? "))')+`
for i in range(1, 10):
    print(dan, "x", i, "=", dan * i)`}],
[/숫자맞추기|업다운|updown/i,()=>`import random
answer = random.randint(1, 100)
count = 0
while True:
    guess = int(input("1~100 숫자를 맞춰 보세요: "))
    count += 1
    if guess > answer:
        print("더 작아요")
    elif guess < answer:
        print("더 커요")
    else:
        print(count, "번 만에 맞췄어요!")
        break`],
[/계산기/,()=>`a = float(input("첫 번째 숫자: "))
op = input("연산 (+ - * /): ")
b = float(input("두 번째 숫자: "))
if op == "+":
    print(a + b)
elif op == "-":
    print(a - b)
elif op == "*":
    print(a * b)
elif op == "/":
    if b == 0:
        print("0으로 나눌 수 없어요")
    else:
        print(a / b)
else:
    print("모르는 연산이에요")`],
[/가위바위보/,()=>`import random
choices = ["가위", "바위", "보"]
me = input("가위, 바위, 보 중 하나: ")
com = random.choice(choices)
print("컴퓨터:", com)
if me == com:
    print("비겼어요")
elif (me == "가위" and com == "보") or (me == "바위" and com == "가위") or (me == "보" and com == "바위"):
    print("이겼어요!")
else:
    print("졌어요")`],
[/짝수.*홀수|홀수.*짝수|짝홀|짝수인지|홀수인지/,()=>`num = int(input("숫자를 입력하세요: "))
if num % 2 == 0:
    print("짝수예요")
else:
    print("홀수예요")`],
[/팩토리얼|계승/,()=>`n = int(input("숫자를 입력하세요: "))
result = 1
for i in range(1, n + 1):
    result *= i
print(n, "! =", result)`],
[/피보나치/,()=>`n = int(input("몇 번째까지 볼까요? "))
a, b = 0, 1
for i in range(n):
    print(a)
    a, b = b, a + b`],
[/소수(인지|판별|찾|구하)/,()=>`n = int(input("숫자를 입력하세요: "))
is_prime = n > 1
for i in range(2, n):
    if n % i == 0:
        is_prime = False
        break
if is_prime:
    print(n, "은(는) 소수예요")
else:
    print(n, "은(는) 소수가 아니에요")`],
[/별찍기|별만들|별을?출력|삼각형/,t=>{const n=t.match(/(\d+)(줄|층|단)/);return 'n = '+(n?n[1]:5)+`
for i in range(1, n + 1):
    print("*" * i)`}],
[/^(?!.*(리스트|목록)).*평균/,()=>`a = int(input("첫 번째 점수: "))
b = int(input("두 번째 점수: "))
c = int(input("세 번째 점수: "))
print("평균:", (a + b + c) / 3)`],
[/섭씨|화씨|온도변환/,()=>`c = float(input("섭씨 온도: "))
f = c * 9 / 5 + 32
print("화씨:", f)`],
[/BMI|체질량|비만도/i,()=>`height = float(input("키(cm): "))
weight = float(input("몸무게(kg): "))
bmi = weight / ((height / 100) ** 2)
print("BMI:", round(bmi, 1))
if bmi < 18.5:
    print("저체중")
elif bmi < 25:
    print("정상")
else:
    print("과체중")`],
[/약수/,()=>`n = int(input("숫자를 입력하세요: "))
for i in range(1, n + 1):
    if n % i == 0:
        print(i)`],
[/(문자열|글자|단어).*(뒤집|거꾸로)|거꾸로/,()=>`text = input("글자를 입력하세요: ")
print(text[::-1])`],
[/글자수|문자열길이|글자개수/,()=>`text = input("글자를 입력하세요: ")
print(len(text))`],
[/현재시간|지금시간|오늘날짜|현재시각|지금몇시/,()=>`import datetime
now = datetime.datetime.now()
print(now.strftime("%Y-%m-%d %H:%M:%S"))`],
[/카운트다운|타이머/,()=>`import time
n = int(input("몇 초부터 셀까요? "))
for i in range(n, 0, -1):
    print(i)
    time.sleep(1)
print("끝!")`],
[/윤년/,()=>`year = int(input("연도를 입력하세요: "))
if (year % 4 == 0 and year % 100 != 0) or year % 400 == 0:
    print("윤년이에요")
else:
    print("윤년이 아니에요")`],
[/학점|성적등급/,()=>`score = int(input("점수를 입력하세요: "))
if score >= 90:
    print("A")
elif score >= 80:
    print("B")
elif score >= 70:
    print("C")
else:
    print("D")`],
[/자기소개/,()=>`name = input("이름: ")
age = int(input("나이: "))
print("안녕하세요, 저는", name, "이고", age, "살이에요.")`]
];
function vibe(text){
 const ctx={vars:new Set(userNames),pre:[],last:null,res:null,list:null,imp:0};
 const tt=text.replace(/\s+/g,'');
 for(const [re,f] of TP){if(!/재귀/.test(tt)&&re.test(tt)){const code=f(tt);if(code)return{code}}}
 const parts=text.split(/\s*(?:\.(?!\d)|[\n;]|그리고|그다음에?|그 다음에?|다음에|한\s*뒤에|한\s*후에)\s*/).map(s=>s.trim()).filter(Boolean);
 const out=[],asks=[];let lastIf=false;
 for(const c of parts){
  ctx.pre=[];
  const em=c.match(/^(?:아니면|그렇지\s*않으면|아니라면)[\s,]*(.*)$/);
  if(em&&lastIf){const e=clause(em[1],ctx);if(e){out.push('else:',...ind([...ctx.pre,...e]));lastIf=false;continue}}
  const ls=clause(c,ctx);
  if(!ls){asks.push(c);continue}
  out.push(...ctx.pre,...ls);lastIf=ls[0].startsWith('if ')&&!ls.includes('else:');
 }
 let ask='';
 if(asks.length)ask='이해하지 못한 문장: '+asks.map(s=>'"'+s+'"').join(', ')+(ctx.sug&&ctx.sug.length?' / 혹시 이런 말인가요? 아래 버튼을 눌러 보세요.':' / 이렇게 써 보세요: 1부터 10까지 출력, 이름 입력받아 안녕 출력, a가 10보다 크면 "큼" 출력 아니면 "작음" 출력, 구구단 3단');
 return{code:out.join('\n'),ask,sug:asks.length?(ctx.sug||[]):[]}}
let samP=null,vbusy=false,vundoVal=null;
try{if(window.claude&&claude.use)samP=claude.use('sample')}catch(e){samP=null}
const vhist=[];
function parseAI(txt){
 let t=(txt||'').trim().replace(/^```(?:json|python)?\s*/i,'').replace(/```\s*$/,'').trim();
 try{return JSON.parse(t)}catch(e){}
 const m=t.match(/\{[\s\S]*\}/);if(m){try{return JSON.parse(m[0])}catch(e){}}
 return{mode:'append',code:t.replace(/```/g,''),note:''}}
async function aiVibe(t){
 if(!samP)return null;
 const sm=await Promise.race([samP,new Promise(r=>setTimeout(()=>r(null),4000))]);
 if(!sm)return null;
 const cur=ta.value.length>6000?ta.value.slice(0,6000)+'\n# ...(이하 생략)':ta.value;
 const hist=vhist.slice(-5).map((h,i)=>(i+1)+'. '+h).join('\n')||'(없음)';
 const prompt='당신은 파이썬 초보자를 돕는 코드 생성기입니다. 사용자가 한국어로 말한 내용을 파이썬 코드로 바꿔 주세요.\n'+
'규칙:\n'+
'- 코드는 Skulpt(브라우저용 파이썬 3 실행기)에서 돌아가야 합니다. 라이브러리는 math, random, time, datetime 정도만 쓰고, f-string과 외부 라이브러리는 피하세요. 입력은 input(), 출력은 print()를 쓰세요.\n'+
'- 초보자가 읽기 쉽게 짧은 한국어 주석을 넣고, 코드는 단순하게 쓰세요.\n'+
'- 변수 이름을 정해 주지 않았으면 a, b, c 같은 짧은 이름이나 뜻이 분명한 영어 이름을 직접 정하세요.\n'+
'- 꼭 필요한 정보가 없어서 도저히 만들 수 없을 때만 code를 비우고 ask에 한국어로 필요한 정보를 물어보세요. 웬만하면 합리적으로 정해서 만드세요.\n'+
'- 사용자가 기존 코드를 고치거나 바꿔 달라고 하면 mode를 "replace"로 하고 고친 전체 코드를 code에 넣으세요. 그 밖에는 mode를 "append"로 하고 새로 추가할 코드만 code에 넣으세요. 이미 있는 변수와 함수는 다시 만들지 말고 이어서 쓰세요.\n'+
'- 응답은 JSON 객체 하나만 쓰세요(설명이나 코드블록 표시 금지): {"mode":"append","code":"파이썬 코드","note":"한국어 한 줄 설명","ask":""}\n\n'+
'현재 편집기 코드:\n<<<\n'+cur+'\n>>>\n\n이전에 사용자가 한 요청들:\n'+hist+'\n\n이번 요청: '+t;
 const r=await sm(prompt,{modelTier:'default',cache:false});
 return parseAI(r.text)}
async function runVibe(){
 const t=vin.value.trim();
 if(!t){vh.textContent='만들고 싶은 코드를 한국어로 적어 주세요.';return}
 if(vbusy)return;
 vbusy=true;$('#vgo').disabled=true;
 let r=null,msg='';
 try{vh.textContent='AI가 코드를 만드는 중이에요...';r=await aiVibe(t)}
 catch(e){msg=e&&e.code==='not_granted'?'AI 사용 허락이 없어서 기본 규칙으로 만들었어요. ':e&&e.code==='rate_limited'?'AI를 너무 자주 불러서 기본 규칙으로 만들었어요. ':'AI를 못 불러서 기본 규칙으로 만들었어요. '}
 if(!r){
  if(!msg)msg='';
  try{r=vibe(t)}catch(e){r={code:'',ask:'이 문장은 아직 못 바꿔요. 조금 더 쉽게 나눠서 적어 주세요.'}}
 }
 else msg='';
 const code=(r.code||'').replace(/\s+$/,'');
 if(code){
  vundoVal=ta.value;$('#vundo').style.display='';
  if(r.mode==='replace')ta.value=code+'\n';
  else{let v=ta.value;if(v&&!v.endsWith('\n'))v+='\n';if(v.trim())v+='\n';ta.value=v+code+'\n'}
  vin.value='';update();wrap.scrollTop=r.mode==='replace'?0:wrap.scrollHeight;vhist.push(t)}
 vh.textContent=msg+(code?(r.mode==='replace'?'코드를 고쳤어요. ':'코드를 아래에 넣었어요. '):'')+(r.note||'')+(r.ask?' '+r.ask:'');
 if(r.sug&&r.sug.length){const w=document.createElement('div');w.style.cssText='display:flex;gap:6px;flex-wrap:wrap;margin-top:4px';r.sug.forEach(x=>{const b=document.createElement('button');b.type='button';b.className='chip';b.textContent=x;b.onclick=()=>{vin.value=x;vin.focus()};w.appendChild(b)});vh.appendChild(w)}
 vbusy=false;$('#vgo').disabled=false}
$('#vundo').onclick=()=>{if(vundoVal===null)return;ta.value=vundoVal;vundoVal=null;$('#vundo').style.display='none';update();vh.textContent='방금 넣은 코드를 되돌렸어요.'};
$('#vgo').onclick=runVibe;
vin.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();runVibe()}});
$('#vibe').onclick=()=>{VP.classList.toggle('open');if(VP.classList.contains('open'))vin.focus()};

ta.value='name = input("이름이 뭐예요? ")\nprint("안녕", name)\n';
update();
